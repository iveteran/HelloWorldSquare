#ifndef _ERROR_CODE_H
#define _ERROR_CODE_H

namespace evt_loop {

const int ERR_CODE_CONN_BUFFER_FULL = 30000;
const int ERR_CODE_SERVERITY = 50000;

}  // ns evt_loop

#endif  // _ERROR_CODE_H
